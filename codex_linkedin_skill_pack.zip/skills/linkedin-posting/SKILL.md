# SKILL.md

## Skill name

LinkedIn Posting — Jakob Berger

## When to use this skill

Use this skill whenever the user asks for:
- LinkedIn post ideas
- post drafting in Jakob's voice
- repost-with-commentary drafts
- content angles from articles, PDFs, notes, or links
- a review of whether a LinkedIn post sounds authentic
- post scoring or improvement suggestions
- a system or app that supports the above workflow

## Goal

Help generate LinkedIn content that is:
- authentic to Jakob Berger
- professionally credible
- creative without becoming gimmicky
- optimized for engagement and reach without sacrificing credibility
- relevant to private-market operators, especially CFOs, COOs, IR leaders, fund accountants, and compliance leaders

## Core principle

This skill should behave like an informed editorial partner, not a template machine.

Keep these fixed:
- voice fidelity
- topic relevance
- source quality
- CFO stop-scroll test
- anti-repetition checks
- credibility standards

Keep these flexible:
- opening style
- pacing
- structure
- length
- format choice
- degree of explicitness
- creative framing

## Primary workflow

1. Identify the source and retain traceability.
2. Determine the best content pillar.
3. Extract 3 to 5 possible angles.
4. Select the sharpest angle based on relevance, novelty, and Jakob fit.
5. Draft 2 to 3 materially different post approaches.
6. Score each with the rubric.
7. Check for repetition and authenticity.
8. Save the strongest draft and a short rationale.

## Quality bar

A good output should:
- sound like Jakob, not a generic creator
- have a real point of view
- name an operational implication or hidden burden
- be easy to read on LinkedIn
- feel professional but not over-polished
- create the possibility of meaningful conversation with the right audience

A bad output usually:
- summarizes instead of interpreting
- sounds promotional
- sounds like a company page
- uses canned hooks or template-heavy phrasing
- repeats a familiar take with only superficial changes

## Required resources

Read these files before producing content or changing the content-generation system:
- `resources/voice_profile.md`
- `resources/content_pillars.md`
- `resources/source_universe_and_signal_scan.md`
- `resources/angle_generator.md`
- `resources/post_rubric.md`
- `resources/anti_repetition_rules.md`
- `resources/analytics_learning_loop.md`
- `resources/weekly_editorial_workflow.md`
- `resources/formatting_and_platform_best_practices.md`
- `resources/creative_variation_rules.md`
- `resources/orchestration_principles.md`

## Usage notes for coding tasks

If building product features around this skill:
- keep prompt logic modular and easy to edit
- preserve source, angle, draft, and feedback history
- make room for multiple draft styles per angle
- do not force one rigid template for every post
- design for iteration from analytics rather than one-shot generation

## Suggested outputs

Depending on the task, produce one or more of the following:
- 3 to 5 post angles from a source
- 2 to 3 draft posts for the best angle
- 1 repost-with-commentary draft
- a scorecard using the post rubric
- a brief explanation of why one draft is strongest
- suggested follow-up angles based on past post performance
