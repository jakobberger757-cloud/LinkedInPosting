# Post Rubric

## Purpose

Use this rubric to score every draft before it is shown as final.

Score each category from 1 to 5.

## 1. CFO stop-scroll score
Would a fund CFO or COO actually stop for this?

A 5:
- names a real current pain
- sharpens an issue they are already feeling
- feels directly relevant

A 1:
- sounds broad
- sounds like generic industry commentary
- feels like a press release

## 2. Point of view score
Does this post have a real take?

A 5:
- contains interpretation
- names what is being missed
- has tension or judgment

A 1:
- just summarizes an article
- lists facts with no implication
- sounds interchangeable

## 3. Voice fidelity score
Does this sound like Jakob?

A 5:
- peer-to-peer
- sharp but credible
- not loud
- clearly not generic AI output

A 1:
- sounds corporate
- sounds like a consultant
- sounds like a finance influencer account

## 4. Specificity score
Is it concrete?

A 5:
- anchored in a stat, quote, or real observed pattern
- names the operational consequence clearly

A 1:
- vague
- abstract
- mostly filler

## 5. Post discipline score
Is this one idea, well executed?

A 5:
- one clean through-line
- good pacing
- clean close
- no clutter

A 1:
- too many ideas
- messy structure
- weak or generic ending

## Rubric pass/fail guidance

A draft is publishable only if:
- no category is below 3
- voice fidelity is at least 4
- point of view is at least 4
- CFO stop-scroll is at least 4

## Mandatory fail conditions

Fail immediately if:
- it starts with “I”
- it uses an em dash
- it sounds promotional
- it could have been written by a generic finance account
- it is mostly summary
- the close is weak and generic


## 6. Authenticity score
Does this feel like a real person with real judgment, or an optimized content machine?

A 5:
- sounds natural
- carries edge without trying too hard
- feels like something Jakob could plausibly say in conversation

A 1:
- sounds templated
- sounds over-polished
- sounds obviously generated

## Additional fail condition

Fail or rewrite if:
- it feels too polished to be believable
- it sounds like it was reverse-engineered from a viral post formula
