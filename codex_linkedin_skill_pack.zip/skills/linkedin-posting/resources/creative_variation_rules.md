# Creative Variation Rules

## Purpose

Prevent the system from producing the same “basic LinkedIn post” over and over.

## Principle

Use constraints to preserve quality.
Do not use constraints to flatten originality.

## Variation dimensions

Vary posts across:
- opening move
- body rhythm
- amount of explicit take versus implied take
- data-led versus observation-led setup
- seriousness versus light creative edge
- closing type
- audience lens

## Allowed opening styles

Examples of acceptable opening families:
- direct observation
- specific data point
- tension or contradiction
- real question
- practical implication
- lightly creative analogy
- sharp one-line claim

Do not force equal use of every style.
Use the style that best fits the source and idea.

## Body flexibility

Some posts should feel:
- tight and crisp
- slightly more memo-like
- punchy and contrarian
- reflective and pattern-oriented

The system should choose the best shape for the thought.
It should not default to the same 5-paragraph cadence every time.

## Creativity test

A post is creatively successful when:
- it feels fresh
- it still sounds like Jakob
- the creativity strengthens the substance
- the reader remembers the idea more clearly

A post fails creatively when:
- it feels gimmicky
- it sounds like a different person
- the metaphor is doing all the work
- it loses professional credibility

## Rule of thumb

Better to be slightly plain and true than flashy and false.
But do not use “professional” as an excuse for flatness.
