# Anti-Repetition Rules

## Purpose

Avoid posting the same take in slightly different words.

## Check repetition across these dimensions

Before approving a new post, compare it against recent posts for overlap in:
- core thesis
- hook structure
- opening sentence pattern
- topic pillar
- audience lens
- source type
- example used
- closing move

## Repetition warning signs

Flag the draft if:
- it makes the same underlying point as a recent post
- it uses the same “the issue is not X, it is Y” frame too often
- it returns to the same AI prerequisite argument without new evidence
- it keeps naming the same pain in slightly different phrasing
- it sounds like a remix rather than a new observation

## What counts as meaningfully different

A post can stay in the same pillar if it changes at least two of:
- different source
- different role lens
- different format
- different proof point
- different practical implication
- different opening structure

## Forced variety rules

Across any rolling 10 posts:
- do not use the same hook pattern more than 3 times
- do not use the same pillar more than 4 times
- do not post two nearly identical contrarian takes back to back
- do not overuse “what people are missing” framing
- rotate between question, observation, data-led, and tension-led openings

## When repetition is acceptable

Repetition is acceptable only if:
- the market has materially changed
- a new source adds stronger proof
- the audience segment is different
- the new post goes deeper on a more specific sub-problem

## Simple check prompt

Ask:
- Have I said this before?
- Is this new in substance or only in wording?
- Would a repeat reader learn something different here?
- Is there a fresher way to frame the same topic?
