# Analytics Learning Loop

## Purpose

Use post performance to improve future source selection, angles, hooks, and formats.

## Track for every post

Required fields:
- date posted
- primary pillar
- secondary pillar if any
- source title
- source type
- hook type
- post format
- audience lens
- whether an image was used
- final draft text
- thumbs up / thumbs down self-rating

Performance fields:
- impressions
- reactions
- comments
- reposts
- saves if available
- profile views after posting
- follower gain
- inbound messages or conversations started
- quality of commenters

## Metrics that matter most

Prioritize:
1. quality of engagement
2. comments from relevant operators
3. profile views
4. inbound conversations
5. saves
6. impressions

Do not optimize only for vanity reach.

## Weekly review questions

1. Which pillars produced the best comment quality?
2. Which hook types drove the best stop-scroll behavior?
3. Which posts attracted the right audience?
4. Which posts were strong on impressions but weak on quality?
5. Which source types reliably produce better posts?
6. Which formats feel strongest in your voice?
7. Which posts should be mined for follow-up angles?

## Monthly learning outputs

At the end of each month, produce:
- top 5 best-performing posts
- top 3 strongest hook patterns
- top 3 most effective source types
- topics that are getting saturated
- topics that deserve deeper follow-up
- formats to use more
- formats to use less

## Decision rules

Do more of:
- posts that attract CFO/COO/compliance comments
- posts that create inbound conversations
- posts where the point of view is sharp and specific
- posts with strong saves relative to reach

Do less of:
- posts that perform only on impressions
- posts that read like article summaries
- posts that attract broad agreement but little conversation
- posts that feel interchangeable with generic finance content

## Learning loop output format

After every 10 posts, generate:
- what is working
- what is not
- what is getting repetitive
- what pillar to prioritize next
- what hook style to test next
- what source type to test next
