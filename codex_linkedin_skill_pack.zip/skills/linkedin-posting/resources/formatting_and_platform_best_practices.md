# Formatting and Platform Best Practices

## Purpose

Layer real LinkedIn platform behavior onto the writing system without turning it into generic social-media advice.

## Core platform principles

LinkedIn's own guidance is consistent on a few points:
- posts work best when they align with your professional expertise
- authentic, useful posts outperform generic visibility plays
- meaningful conversation matters
- creator analytics should be used to learn what is working
- multiple formats are available, so format should follow the idea

## What this means for Jakob

### 1. Stay tightly aligned to expertise
Default toward topics that fit your lived authority:
- fund operations
- operating models
- investor experience
- compliance burden
- data and AI in private markets

Do not chase broad business commentary unless there is a sharp private-markets operating angle.

### 2. Favor one clear idea per post
A clear post is easier to read, easier to react to, and easier to remember.
Do not cram multiple sub-themes into one post.

### 3. Write for scanability
Use:
- short paragraphs
- clean line breaks
- a strong first line
- concrete nouns
- fast entry into the real point

Avoid:
- walls of text
- long warm-up paragraphs
- abstract throat-clearing

### 4. Optimize for conversation quality, not empty engagement
The best engagement is from the right people:
- CFOs
- COOs
- IR leaders
- fund accountants
- compliance leaders
- adjacent operators in private markets

The system should prefer a post with fewer but more relevant comments over one with broad but low-quality reactions.

### 5. Choose format based on the idea
Possible formats:
- text-only post
- repost with commentary
- image-supported post
- PDF / document carousel
- article or newsletter when depth is warranted

Do not force every idea into the same format.

### 6. Use analytics as part of the writing loop
After posting, capture:
- impressions
- engagements
- post-level audience quality
- profile activity
- follower changes
- whether the post led to real conversations

## Formatting defaults

Default structure:
- strong first line
- one short setup beat if needed
- body with one clear through-line
- close with either a clean observation or a real question

Default paragraphing:
- 1 to 3 sentences per paragraph
- white space is a feature
- break when the thought changes

## Creativity rule

Do not confuse formatting discipline with formula.

The post should feel:
- intentional
- easy to read
- human

It should not feel:
- templated
- optimized by committee
- reverse-engineered from viral creator tropes
