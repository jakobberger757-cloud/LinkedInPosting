# Content Pillars

Every post should map to one primary pillar and, at most, one secondary pillar.

## Pillar 1 — Operating Model Evolution

Topics:
- self-admin vs co-source vs full outsource
- what changes as complexity grows
- when scale breaks a legacy operating model
- what migrations actually involve
- key person risk
- cost shifting versus cost reduction
- who is really the quarterback
- what managers underestimate when retaining internal control

Good angles:
- “The cheaper model often just moves the work”
- “The issue is not outsourcing versus insourcing. It is where the review burden lives”
- “Platform-led and partner-led models solve different problems”

Relevant source example:
The Drawdown piece on platform-led vs partner-led administration and the idea that CFOs should own the judgment, but not necessarily the process.

## Pillar 2 — AI + Data in Fund Ops

Topics:
- what has to be true before AI works
- data quality and ownership
- workflow readiness
- system interoperability
- governance and review
- AI as burden reduction versus AI as demo
- where humans still sit in the loop

Good angles:
- “The AI conversation is real. The prerequisites are what get skipped”
- “Most firms do not have an AI problem. They have a data ownership problem”
- “The value of AI in ops depends on where the judgment still sits”

## Pillar 3 — LP / Investor Experience

Topics:
- onboarding friction
- AML / KYC
- portal fragmentation
- subscription process burden
- reporting expectations
- retail or HNW investor complexity
- cross-border onboarding
- operational ownership of LP experience

Good angles:
- “Investor experience breaks when ops design gets treated like a back-office detail”
- “LP experience and compliance burden are increasingly the same conversation”

## Pillar 4 — Market Structure + Regulatory Shifts

Topics:
- private markets retail access
- fundraising concentration
- SEC / FinCEN / AML shifts
- Luxembourg / AIFMD / cross-border complexity
- admin industry consolidation
- how market shifts force operational decisions

Good angles:
- “A market structure shift is only interesting if you map the operational consequence”
- “Regulatory change is usually discussed at the headline level. The build burden is where the real story lives”

## Pillar prioritization

Default priority:
1. Operating Model Evolution
2. AI + Data in Fund Ops
3. LP / Investor Experience
4. Market Structure + Regulatory Shifts

## Pillar mix target per week

Default weekly mix:
- 2 posts from Pillar 1 or 2
- 1 post from Pillar 3 or 4
- 1 repost with commentary
- 1 optional observational or contrarian post

## Pillar rule

Do not post the same pillar twice in a row unless the second post is materially different in:
- format
- angle
- source type
- audience lens
