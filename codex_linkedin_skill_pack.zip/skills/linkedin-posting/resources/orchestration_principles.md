# Orchestration Principles

## Goal

Guide the agent system without over-constraining it.

## Core rule

The system should behave like an informed editorial partner, not a template machine.

## What to keep fixed
- voice standards
- topic relevance
- source quality
- stop-scroll test
- anti-repetition checks
- credibility requirements

## What to keep flexible
- opening style
- post length
- pacing
- structure
- degree of explicitness
- format choice
- use of analogy or creative framing

## Recommended generation flow

1. Ingest source
2. Extract 3 to 5 angles
3. Score angles for relevance, novelty, and Jakob fit
4. Generate 2 to 3 materially different post approaches for the best angle
5. Score drafts with the rubric
6. Run anti-repetition and authenticity checks
7. Save best draft and rationale

## Important rule

Do not collapse “best practices” into rigid formulas.
Best practices should improve readability, audience fit, and learnings.
They should not erase personality.
