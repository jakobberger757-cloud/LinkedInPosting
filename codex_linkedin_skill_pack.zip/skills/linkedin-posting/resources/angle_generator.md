# Angle Generator

## Purpose

Turn source material into differentiated LinkedIn post angles.

Do not summarize the article.
Do not restate the headline.
Do not produce generic “key takeaways.”

The job is to extract:
- the operational implication
- the hidden burden
- the thing most people will miss
- the buyer-relevant lens
- the stronger point of view

## For every source, generate angles in these buckets

### Bucket 1 — What this means operationally
Translate the source into practical operating reality.

Questions:
- What actually changes for the fund manager?
- What process gets harder?
- What new burden shows up?
- What internal role inherits the complexity?

### Bucket 2 — Hidden burden / cost shift
Look for where the work really goes.

Questions:
- Is the source describing true efficiency or just burden transfer?
- What looks cheaper but becomes more expensive internally?
- What review layer still needs to exist?

### Bucket 3 — What buyers underestimate
Name the blind spot.

Questions:
- What would an operator underprice here?
- What gets ignored in the pitch-deck version of this topic?
- Where is the real friction hiding?

### Bucket 4 — Tech versus people
Separate automation from accountability.

Questions:
- Where does technology help?
- Where does human review still matter?
- Who still owns the judgment?
- What cannot be abstracted away?

### Bucket 5 — Role-specific implication
Translate to audience.

Questions:
- What does this mean for a CFO?
- What does this mean for a COO?
- What does this mean for a Head of IR?
- What does this mean for a compliance leader?

## Angle templates

### Template A — The issue is not X. It is Y.
Use when conventional framing is wrong.

### Template B — Most people are solving for the visible problem
Use when there is a deeper constraint.

### Template C — The thing getting skipped
Use when the discourse is incomplete.

### Template D — This means something different depending on the shop
Use when segmentation matters.

## Output format for each source

Generate:
- 3 to 5 angles
- each angle in 1 to 2 sentences
- one suggested audience lens
- one suggested post format
- one confidence score from 1 to 5

## Angle quality test

A strong angle:
- is not obvious
- is not a summary
- contains real tension or implication
- would make a CFO pause
- can lead to a distinctly Jakob post

A weak angle:
- could apply to any article
- says “this is important”
- just paraphrases the source
- sounds like content marketing

## Example using uploaded Drawdown article

Weak:
- Fund administration is changing and managers need to think about their operating models.

Strong:
- Lower admin fees do not necessarily reduce the burden. In a lot of cases, they just move the review work back onto the manager’s own team.
- The real operating-model question is not whether you want tech or people. It is whether you want to be the quarterback or pay someone else to be.
- The independence debate around admin is less about whether humans are involved and more about who is actually standing behind the work.


## Creativity guardrail

The angle generator should produce disciplined variety, not uniformity.

It may use:
- a clean contrarian angle
- a question
- a vivid framing line
- a practical analogy
- a market-structure lens
- a “coffee conversation” tone

It should not overfit to one formula.
Generate variety first. Narrow later.
