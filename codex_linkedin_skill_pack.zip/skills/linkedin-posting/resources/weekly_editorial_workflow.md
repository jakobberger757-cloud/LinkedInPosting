# Weekly Editorial Workflow

## Goal

Run a lightweight system that consistently turns good source material into strong LinkedIn posts in Jakob’s voice.

## Monday — Signal scan
- collect 10 to 20 source items
- tag each by pillar
- score each for CFO relevance, novelty, and postability
- discard weak items quickly

## Tuesday — Angle selection
- choose the 2 strongest source items
- generate 3 to 5 angles per source
- pick the sharpest 2 or 3 angles
- eliminate anything that reads like summary

## Wednesday — Drafting
- create 2 draft versions for the best angle
- test two different hooks
- run through the post rubric
- save the strongest version

## Thursday — Secondary content
- write 1 repost-with-commentary
- write 2 to 3 smart comments for other industry posts
- optionally create a visual or carousel brief

## Friday — Review and learn
- check post performance
- update analytics fields
- review what is getting traction with the right audience
- decide what pillar and hook style to use next week

## Default posting mix

Target 4 to 5 posts per week:
- 2 original posts from Pillar 1 or 2
- 1 data-led or market-structure post
- 1 repost-with-commentary
- 1 optional observational post

## Pre-post checklist

Before posting, confirm:
- no em dash
- no forbidden phrases
- not starting with “I”
- one clear idea
- real point of view
- strong stop-scroll line
- clean close
- sounds like Jakob
- source is traceable
- not too repetitive relative to recent posts


## Distribution note

Do not optimize only for volume.
Optimize for relevance, expertise, and genuine conversation with the right professional audience.
Use analytics weekly to judge not just reach, but who engaged and whether the post moved the right people.
