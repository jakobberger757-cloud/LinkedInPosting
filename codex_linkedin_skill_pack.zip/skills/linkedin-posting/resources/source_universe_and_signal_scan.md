# Source Universe and Signal Scan

## Tier 1 sources

Pull first:
- Aztec articles, insights, press, and research
- PitchBook
- Preqin
- The Drawdown
- PE CFO / Private Funds CFO
- Financial Times
- Wall Street Journal

The Drawdown is particularly strong for operating-model and fund-admin content.

## Tier 2 sources

Check regularly:
- PEI
- Dakota
- Institutional Investor
- Citywire
- SEC releases
- Dechert alerts
- Sidley alerts
- Debevoise alerts

## Tier 3 sources

Use opportunistically:
- LinkedIn posts from CFOs, COOs, IR leaders, and compliance leaders
- relevant podcast transcripts
- market commentary that intersects with private-market ops
- conference recaps
- survey PDFs
- your own meeting notes and observed patterns

## Source scoring rules

For every source, score from 1 to 5 on:
1. CFO relevance
2. operational specificity
3. credibility
4. novelty
5. postability

## Kill rules

Discard a source if:
- it is just broad market news with no operating implication
- it contains no credible data point and no differentiated angle
- it is too promotional
- it leads to a post that a generic finance account could write
- a CFO probably would not stop scrolling for it

## Signal scan workflow

For each source, answer:
1. Which pillar does this belong to?
2. What is the actual operational implication?
3. What pain does this name?
4. What does it suggest that most people will miss?
5. Who specifically would care: CFO, COO, IR, compliance, accounting?
6. Is there a concrete line, quote, or data point to anchor on?
7. Is this a post, a repost-with-commentary, or a pass?

## Source traceability rule

Every idea should retain:
- source title
- source link or document reference
- publication date if known
- source type
- the exact line, stat, or quote that triggered the angle

## Relevance examples from uploaded material

From the uploaded Drawdown article:
- “Do you want a quarterback, or do you want to be the quarterback?”
- lower fees can simply shift work back to the GP
- even platform providers still require people in the loop
- the real question is who stands behind the output
- CFOs should own the judgment but not necessarily the process
