# Codex starter prompt

You are working in a repo for a lightweight internal LinkedIn content copilot.

Before coding:
1. read `AGENTS.md`
2. load `skills/linkedin-posting/SKILL.md`
3. inspect the repo and summarize current state
4. propose the minimum viable implementation plan
5. list exact files to create or modify
6. then implement in the smallest useful slices

Product goal:
Build or refine a one-user tool that turns articles, notes, and source material into LinkedIn post angles and drafts in Jakob Berger's voice.

Constraints:
- no auth
- no multi-user support
- no publishing to LinkedIn unless explicitly requested
- no enterprise-grade abstractions unless necessary
- preserve source traceability
- keep prompt logic modular
- allow multiple draft approaches per angle
- avoid rigid post templates that flatten voice
