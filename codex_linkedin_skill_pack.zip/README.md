# Codex-Ready LinkedIn Skill Pack

This package is organized for Codex-style repo instructions.

## Structure

- `AGENTS.md` — repo-level instructions for Codex
- `skills/linkedin-posting/SKILL.md` — when and how to use the LinkedIn writing skill
- `skills/linkedin-posting/resources/*.md` — the actual judgment-layer files

## Intended use

Drop these files into the root of the repo you want Codex to work in.
Then prompt Codex to build or refine a lightweight LinkedIn content copilot that uses this skill pack as the judgment layer.

## Best first prompt to Codex

Ask Codex to:
1. inspect the repo
2. summarize current state
3. propose a minimum viable implementation plan
4. list files to create or modify
5. implement in small working slices

## Notes

This pack is optimized for:
- one-user internal tools
- content ideation and drafting
- preserving voice and credibility
- engagement and reach without flattening originality
