# AGENTS.md

## Purpose

This repository contains a lightweight internal tool for Jakob Berger's LinkedIn content workflow.
The tool is intended to help transform articles, notes, and source material into thoughtful LinkedIn post ideas and drafts in Jakob's voice.

## Default behavior

When working in this repo:
- optimize for speed to a useful MVP
- prefer minimal, readable implementations over abstract architecture
- preserve a clean local developer experience
- avoid unnecessary infra, auth, background workers, or enterprise patterns unless explicitly requested
- treat this as a one-user internal tool unless instructed otherwise

## LinkedIn writing tasks

If the task involves any of the following:
- LinkedIn post ideation
- thought-leadership drafting
- repost commentary
- content angle generation
- source-to-post transformation
- post scoring or post analytics review

Then load and follow the `skills/linkedin-posting/SKILL.md` skill before making changes.

## App-level rules

- Do not build LinkedIn publishing or browser automation unless explicitly requested.
- Do not build multi-user systems, billing, role-based access, or unnecessary infra.
- Keep prompt logic in clearly named files.
- Preserve source traceability so every generated idea can be traced back to source material.
- Avoid hard-coded generic social-media templates that flatten voice.
- Favor judgment, readability, and credibility over “growth hack” behavior.

## Delivery style

When proposing changes:
1. summarize the current state
2. propose the minimum implementation plan
3. list the files to create or modify
4. state assumptions and tradeoffs
5. then implement in the smallest useful slices
